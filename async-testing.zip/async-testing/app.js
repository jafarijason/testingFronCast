const { outputTitle } = require('./util')

const btn = document.querySelector('button')

btn.addEventListener('click', outputTitle)